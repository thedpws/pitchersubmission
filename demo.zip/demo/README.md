# Example Project
This is a jupyter notebook using our Pitchr framework to create a simple song.

## Installing dependencies
`pip3 install -r requirements.txt`

## Running the example project


### Starting Jupyter lab
In the (example) project directory start a local Jupyter Notebook server using `jupyter notebook`

### Accessing Jupyter Lab
Open in a browser: `http://localhost:8000` and select `Demo.ipynb`
